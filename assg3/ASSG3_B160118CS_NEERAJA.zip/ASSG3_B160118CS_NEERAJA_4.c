#include<stdio.h>
long heapsize=0;
long size=10000;
struct heap
{
long val;
long priority;
}pq[10000],temp;


long parent(long i)
{
return i/2;
}

void insert(struct  heap pq[size],long elem,long pr)
{

heapsize++;
pq[heapsize].val=elem;
pq[heapsize].priority=pr;
long i=heapsize;
while((i>1)&&(pq[parent(i)].priority>pq[i].priority))
{
	temp=pq[parent(i)];
	pq[parent(i)]=pq[i];
	pq[i]=temp;
	i=parent(i);
}
	
}

void min_heapify(struct heap pq[size],long i)
{

long smallest,temp;
//if(i<=heapsize)
//{
	smallest=i;
	if((2*i<=heapsize)&&(pq[2*i].priority<smallest))
		smallest=2*i;
	if((2*i+1<heapsize)&&(pq[2*i+1].priority<pq[smallest].priority))
		smallest=2*i+1;
	if(smallest!=i)
		{temp=pq[smallest].priority;
		pq[smallest].priority=pq[i].priority;
		pq[i].priority=temp;

		min_heapify(pq,smallest);
		}
//}

}

void extract_min(struct heap pq[size])
{
if (heapsize==0)
{
	printf("EMPTY\n");
	return;
}
long x,y;
x=pq[1].val;
y=pq[1].priority;
pq[1]=pq[heapsize];
heapsize--;

//min_heapify(pq,1);///////////////////////doubttttttt
printf("%ld ",x);
	printf("(%ld)\n",y);
}

void get_min(struct heap pq[size])
{
	if (heapsize==0)
{
	printf("EMPTY\n");
	return;
}

printf("%ld ",pq[1].val);
printf("(%ld)\n",pq[1].priority);
}


void decrease_priority(struct heap pq[size],long elem,long newpr)

{
	long i;
	for(i=1;i<heapsize;++i)
	{
		if(pq[i].val==elem)
		{
			break;
		}

	}

	pq[i].priority=newpr;
	i=heapsize;
	while((i>1)&&(pq[parent(i)].priority>pq[i].priority))
{
	temp=pq[parent(i)];
	pq[parent(i)]=pq[i];
	pq[i]=temp;
	i=parent(i);
}
}



void main()
{


char ch;
long elem;

long pr,newpr;

while(1)
{
	scanf("%c",&ch);

	
	if(ch=='s')
	return ;

	if(ch=='a')
	{
//	printf("%c",ch);
	scanf("%ld",&elem);
	scanf("%ld",&pr);
	insert(pq,elem,pr);
	
	}

	if(ch=='e')
	{
	extract_min(pq);
	

	}

	if(ch=='g')
	{
	get_min(pq);
	}

	if(ch=='d')
	{
	scanf("%ld",&elem);
	scanf("%ld",&newpr);
	decrease_priority(pq,elem,newpr);
	}
}
}

